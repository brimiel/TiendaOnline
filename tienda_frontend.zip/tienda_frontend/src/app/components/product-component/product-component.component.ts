import {Component, Input, OnInit} from '@angular/core';
import {Producto} from "../../models/Producto";
import {CarritoService} from "../../services/carrito.service";
import {ProductoCarrito} from "../../models/ProductoCarrito";

@Component({
  selector: 'app-product-component',
  templateUrl: './product-component.component.html',
  styleUrls: ['./product-component.component.scss']
})
export class ProductComponentComponent implements OnInit {

  // @ts-ignore
  @Input() producto: Producto;
  cantidad: number;

  constructor(private carrito: CarritoService) {
    this.cantidad = 0;
  }

  ngOnInit(): void {
  }

  agregarCarrito(cantidad: HTMLInputElement) {
    let cantidadSeleccionada = parseInt(cantidad.value);
    if (cantidadSeleccionada != 0) {
      this.carrito.agregarProducto(new ProductoCarrito(this.producto.id, cantidadSeleccionada));
      localStorage.setItem('carrito', JSON.stringify(this.carrito.getProductos()));
    }

    return false;
  }
}
