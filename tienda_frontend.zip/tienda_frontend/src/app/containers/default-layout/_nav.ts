import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Productos',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' }
  },
  {
    title: true,
    name: 'Carrito'
  },
  {
    name: 'Ver carrito',
    url: '/theme/colors',
    iconComponent: { name: 'cil-cart' }
  }
];
