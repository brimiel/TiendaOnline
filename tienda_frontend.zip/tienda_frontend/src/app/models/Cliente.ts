export class Cliente {
  id: number = 0;
  nombreCompleto: string;
  email: string;
  password: string;
  telefono: string;

  constructor(nombreCompleto: string, email: string, password: string, telefono: string) {
    this.nombreCompleto = nombreCompleto;
    this.email = email;
    this.password = password;
    this.telefono = telefono;
  }
}
