export class Producto {
  id: number = 0;
  nombre: String;
  descripcion: String;
  precioCompra: number;
  precio_venta: number;
  minimoStock: number;
  cantidad: number;
  categoriaId: number;


  constructor(nombre: String, descripcion: String, precioCompra: number, precioVenta: number, minimoStock: number, cantidad: number, categoriaId: number) {
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.precioCompra = precioCompra;
    this.precio_venta = precioVenta;
    this.minimoStock = minimoStock;
    this.cantidad = cantidad;
    this.categoriaId = categoriaId;
  }
}
