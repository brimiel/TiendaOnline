import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Cliente} from "../models/Cliente";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  url = 'http://localhost:8080/api/cliente'

  constructor(private http: HttpClient) {
  }

  registrarCliente(cliente: Cliente) : Observable<Cliente> {
    return this.http.post<Cliente>(this.url, cliente);
  }

  login(cliente: Cliente) : Observable<Cliente> {
    return this.http.post<Cliente>(this.url + '/login', cliente);
  }
}
