import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {ProductoCarrito} from "../models/ProductoCarrito";
import {Observable} from "rxjs";
import {Cliente} from "../models/Cliente";

@Injectable({
  providedIn: 'root'
})
export class CarritoService {
  url = 'http://localhost:8080/api/carrito';
  carrito: Array<ProductoCarrito>;

  constructor(private http: HttpClient) {
    this.carrito = [];
  }

  agregarProducto(producto: ProductoCarrito) {
    this.carrito.push(producto);
  }

  getProductos() {
    return this.carrito;
  }

  comprar(carrito: string) : Observable<any> {
    console.log(carrito);
    return this.http.post<any>(this.url + '/comprar', carrito);
  }
}
