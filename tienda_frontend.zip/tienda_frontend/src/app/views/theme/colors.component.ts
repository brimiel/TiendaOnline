import {AfterViewInit, Component, HostBinding, Inject, Input, OnInit, Renderer2} from '@angular/core';
import {DOCUMENT} from '@angular/common';

import {getStyle, rgbToHex} from '@coreui/utils/src';
import {CarritoService} from "../../services/carrito.service";
import {ProductoCarrito} from "../../models/ProductoCarrito";
import {Producto} from "../../models/Producto";
import {ProductoService} from "../../services/producto.service";

@Component({
  templateUrl: 'colors.component.html'
})
export class ColorsComponent implements OnInit, AfterViewInit {
  productosCarrito: ProductoCarrito[] = [];
  productos: Producto[] = [];
  total: number = 0;

  constructor(
    @Inject(DOCUMENT) private document: HTMLDocument,
    private renderer: Renderer2,
    private carritoService: CarritoService,
    private productoService: ProductoService
  ) {
    this.productosCarrito = carritoService.getProductos();

    this.productosCarrito = JSON.parse(<string>localStorage.getItem('carrito'));





    console.log(this.total);
  }

  public themeColors(): void {
    Array.from(this.document.querySelectorAll('.theme-color')).forEach(
      // @ts-ignore
      (el: HTMLElement) => {
        const background = getStyle('background-color', el);
        const table = this.renderer.createElement('table');
        table.innerHTML = `
          <table class='table w-100'>
            <tr>
              <td class='text-muted'>HEX:</td>
              <td class='font-weight-bold'>${rgbToHex(background)}</td>
            </tr>
            <tr>
              <td class='text-muted'>RGB:</td>
              <td class='font-weight-bold'>${background}</td>
            </tr>
          </table>
        `;
        this.renderer.appendChild(el.parentNode, table);
        // @ts-ignore
        // el.parentNode.appendChild(table);
      }
    );
  }

  ngOnInit(): void {
    // this.themeColors();
    this.productoService.getProductos().subscribe((data) => {
      this.productos = data;
      this.calcularTotal();
    });
  }

  ngAfterViewInit(): void {
    this.themeColors();
  }

  buscarProducto(productoId: number, cantidad: number) {
    for (const producto of this.productos) {
      if (producto.id == productoId) {
        return producto;
      }
    }

    return this.productos[0];
  }

  calcularTotal() {
    for (const e of this.productosCarrito) {
      for (const f of this.productos) {
        if (e.productoId == f.id) {
          this.total += f.precio_venta * e.cantidad;
        }
      }
    }
  }

  comprar() {
    let usuarioId = parseInt(JSON.parse(<string>localStorage.getItem('usuario')).id);

    let carrito = {
      usuarioId,
      carrito: this.productosCarrito
    }

    this.carritoService.comprar(JSON.stringify(carrito)).subscribe((data) => {
      console.log(data);
    }, (error => {
      console.log(error);
    }));

    return false;
  }
}

@Component({
  selector: 'app-theme-color',
  template: `
    <c-col xl='2' md='4' sm='6' xs='12' class='my-4 ms-4'>
      <div [ngClass]='colorClasses' style='padding-top: 75%;'></div>
      <ng-content></ng-content>
    </c-col>
  `
})
export class ThemeColorComponent implements OnInit {
  @Input() color = '';
  public colorClasses = {
    'theme-color w-75 rounded mb-3': true
  };

  @HostBinding('style.display') display = 'contents';

  ngOnInit(): void {
    this.colorClasses = {
      ...this.colorClasses,
      [`bg-${this.color}`]: !!this.color
    };
  }
}

