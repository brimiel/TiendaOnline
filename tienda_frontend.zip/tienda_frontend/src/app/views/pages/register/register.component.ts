import { Component } from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {Cliente} from "../../../models/Cliente";
import {ClienteService} from "../../../services/cliente.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {

  nombreCompleto = new FormControl('', [Validators.required, Validators.maxLength(48)]);
  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required, Validators.maxLength(32)]);
  passwordRepeat = new FormControl('', [Validators.required, Validators.maxLength(32)]);

  constructor(private clienteService: ClienteService, private router:Router) {

  }

  registrarUsuario(nombreCompleto: HTMLInputElement, email: HTMLInputElement, password: HTMLInputElement, telefono: HTMLInputElement) {
    let nuevoCliente : Cliente = new Cliente(nombreCompleto.value, email.value, password.value, telefono.value);

    console.log(nuevoCliente);

    this.clienteService.registrarCliente(nuevoCliente).subscribe((data) => {
      this.router.navigate(['/login']);
    });

    return false;
  }
}
