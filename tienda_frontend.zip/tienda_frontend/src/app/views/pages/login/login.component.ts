import { Component } from '@angular/core';
import {Cliente} from "../../../models/Cliente";
import {Router} from "@angular/router";
import {ClienteService} from "../../../services/cliente.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  constructor(private router:Router, private clienteService: ClienteService) { }

  iniciarSesion(email: HTMLInputElement, password: HTMLInputElement) {
    let cliente : Cliente = new Cliente('', email.value, password.value, '');

    this.clienteService.login(cliente).subscribe((data) => {
      if (data.id == 0 || data.id == -1) {
        alert('Las credenciales no son válidas.');
      } else {
        localStorage.setItem('usuario', JSON.stringify(data));
        this.router.navigate(['/dashboard']);
      }
    });

    return false;
  }
}
